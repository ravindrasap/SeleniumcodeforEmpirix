package CSV_Reader;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Script_IL.Ameyo_Login;
import Utility.Base;

public class ReadCSVFile {

	private static final String COMMA_DELIMITER = ",";

	public static void main(String args[]) {
		BufferedReader br = null;
		try {

			br = new BufferedReader(new FileReader(Base.loadPropertiesFile("crm_PL_data.properties", "csv_path")));

			List<CSVFileData> empList = new ArrayList<CSVFileData>();

			String line = "";

			br.readLine();

			while ((line = br.readLine()) != null) {

				String[] eligibilityDetails = line.split(COMMA_DELIMITER);

				if (eligibilityDetails.length > 0) {

					CSVFileData emp = new CSVFileData(eligibilityDetails[0], eligibilityDetails[1],eligibilityDetails[2]);
					empList.add(emp);
				}
			}

			Ameyo_Login verifycrm = new Ameyo_Login();
			verifycrm.verifyLogin(empList);

		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException ie) {
				System.out.println("Error occured while closing the BufferedReader");
				ie.printStackTrace();
			}
		}
	}
}