package CSV_Reader;


import java.io.Serializable;

public class CSVFileData implements Serializable
{
    private String email;
    private String password;
	private String campaianname;
    
    			
    public String getemail() {
		return email;
	}

	public void setemail(String email) {
		this.email = email;
	}

	public String getpassword() {
		return password;
	}
	
	public void setpassword(String password) {
		this.password = password;
	}
	
	public String getcampaianname() {
		return campaianname;
	}

	
	public void setcampaiannamed(String campaianname) {
		this.campaianname = campaianname;
	}

	public CSVFileData(String email, String password, String campainname) {
        super();
        this.email = email;
        this.password = password;
        this.campaianname = campaianname;
              
    }
    
/*    public String getemail() {
        return email;
    }
    public void setemail(String email) {
        this.email = email;
    }
    
    public String getpassword() {
        return password;
    }
    public void setpassword(String password) {
        this.password = password;
    }*/
   

    @Override
    public String toString() {
        return "Employee [email=" + email + ", password=" + password+" , campaianname=" + campaianname + "]";
    }

	

}