package test;

import java.util.List;

public class PatientDataCreator {

	public List<Patient> createPatients() {
		// TODO Auto-generated method stub
		return null;
	}

}
